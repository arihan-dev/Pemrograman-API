const Albums = () => {
    return (
        <div>ALBUM  PAGE</div>
    )
}

export default Albums